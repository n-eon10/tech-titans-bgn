import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom'; // Add Routes and Route
import './App.css';
import SideBar from './components/ui/sidebar.jsx';
import LogIn from './pages/login';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <SideBar />
        <Routes>
          <Route path="/" element={<LogIn />} /> {/* Define the default route */}
          <Route path="/dashboard" element={<h1>Dashboard</h1>} />
          <Route path="/shiftlogs" element={<h1>Shift Logs</h1>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
